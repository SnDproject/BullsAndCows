var arr = [];

console.log(arr);

arr.splice(2, 1, 'HI');
console.log('*************AFTER SPLICING*************');
console.log(arr[0]);
