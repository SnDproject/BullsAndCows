
module.exports = {
    getHome: function (req, res) {

            res.send({name: 'Bulls And Cows', type: 'test'});
        }

    }
